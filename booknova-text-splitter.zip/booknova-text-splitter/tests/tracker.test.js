'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const T = require('../www/js/tracker.js');
const S = require('../www/js/splitter.js');

const mk = (...texts) => texts.map((t, i) => ({ number: i + 1, text: t, chars: t.length, id: S.sectionId(t) }));
const sig = secs => S.sectionId(secs.map(s => s.id).join('|'));

test('copying a section records number, timestamp and content id', () => {
  const secs = mk('one', 'two', 'three');
  const st = T.recordSectionCopy(T.emptyState(), secs[1], 1000);
  assert.equal(st.lastOperation, 'section');
  assert.deepEqual(st.lastSection, { number: 2, id: secs[1].id, chars: 3, copiedAt: 1000 });
});

test('copying another section moves the single marker', () => {
  const secs = mk('one', 'two', 'three');
  let st = T.recordSectionCopy(T.emptyState(), secs[0], 1);
  st = T.recordSectionCopy(st, secs[2], 2);
  const r = T.reconcile(st, secs, sig(secs));
  assert.equal(r.section.status, 'active');
  assert.equal(r.section.index, 2);
});

test('marker survives a persist/restore round trip', () => {
  const secs = mk('one', 'two');
  const st = T.recordSectionCopy(T.emptyState(), secs[1], 5);
  const restored = T.sanitize(JSON.parse(JSON.stringify(st)));
  assert.deepEqual(restored, st);
  assert.equal(T.reconcile(restored, secs, sig(secs)).section.index, 1);
});

test('edited content invalidates the marker instead of pointing at an unrelated section', () => {
  const before = mk('one', 'two', 'three');
  const st = T.recordSectionCopy(T.emptyState(), before[1], 5);
  const after = mk('one', 'TWO CHANGED', 'three');
  const r = T.reconcile(st, after, sig(after));
  assert.equal(r.section.status, 'stale');
  assert.equal(r.section.index, -1);
});

test('same content at a new position: marker follows the content', () => {
  const before = mk('one', 'two', 'three');
  const st = T.recordSectionCopy(T.emptyState(), before[2], 5);
  const after = mk('zero', 'one', 'two', 'three');
  const r = T.reconcile(st, after, sig(after));
  assert.equal(r.section.status, 'active');
  assert.equal(r.section.index, 3);
  assert.equal(r.changed, true);
  assert.equal(r.state.lastSection.number, 4);
});

test('identical duplicate sections: the nearest to the recorded number wins', () => {
  const secs = mk('dup', 'x', 'dup');
  const st = T.recordSectionCopy(T.emptyState(), secs[2], 5);
  assert.equal(T.reconcile(st, secs, sig(secs)).section.index, 2);
});

test('stale marker comes back if the text is restored', () => {
  const orig = mk('one', 'two');
  const st = T.recordSectionCopy(T.emptyState(), orig[1], 5);
  assert.equal(T.reconcile(st, mk('one', 'zzz'), 'x').section.status, 'stale');
  assert.equal(T.reconcile(st, orig, sig(orig)).section.status, 'active');
});

test('copy all is tracked separately and does not mark any section', () => {
  const secs = mk('one', 'two');
  const st = T.recordCopyAll(T.emptyState(), { signature: sig(secs), sectionCount: 2, chars: 6 }, 9);
  assert.equal(st.lastOperation, 'all');
  assert.equal(st.lastSection, null);
  const r = T.reconcile(st, secs, sig(secs));
  assert.equal(r.section.status, 'none');
  assert.equal(r.section.index, -1);
  assert.equal(r.all.status, 'active');
});

test('copy all becomes stale when sections change', () => {
  const a = mk('one', 'two');
  const st = T.recordCopyAll(T.emptyState(), { signature: sig(a), sectionCount: 2, chars: 6 }, 9);
  const b = mk('one', 'three');
  assert.equal(T.reconcile(st, b, sig(b)).all.status, 'stale');
});

test('section marker and copy-all indicator coexist; last operation is remembered', () => {
  const secs = mk('one', 'two');
  let st = T.recordSectionCopy(T.emptyState(), secs[0], 1);
  st = T.recordCopyAll(st, { signature: sig(secs), sectionCount: 2, chars: 6 }, 2);
  assert.equal(st.lastOperation, 'all');
  const r = T.reconcile(st, secs, sig(secs));
  assert.equal(r.section.index, 0);
  assert.equal(r.all.status, 'active');
  st = T.recordSectionCopy(st, secs[1], 3);
  assert.equal(st.lastOperation, 'section');
});

test('history is capped and newest first', () => {
  const secs = mk('a');
  let st = T.emptyState();
  for (let i = 0; i < 50; i++) st = T.recordSectionCopy(st, secs[0], i);
  assert.equal(st.history.length, T.HISTORY_LIMIT);
  assert.equal(st.history[0].copiedAt, 49);
});

test('sanitize copes with corrupt storage', () => {
  for (const bad of [null, undefined, 5, 'x', [], { lastSection: { number: 'a' } }, { history: 'no' }]) {
    const s = T.sanitize(bad);
    assert.equal(s.lastSection, null);
    assert.equal(s.lastOperation, null);
    assert.deepEqual(s.history, []);
  }
});
