'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../www/js/splitter.js');

const join = r => r.sections.map(s => s.text).join('');
const maxLen = r => Math.max(0, ...r.sections.map(s => s.text.length));

function checkInvariants(text, target, smart = true) {
  const r = S.splitText(text, target, { smart });
  assert.equal(r.ok, true);
  assert.equal(join(r), text, 'text must be preserved exactly');
  assert.ok(maxLen(r) <= r.hardMax, `section ${maxLen(r)} exceeds hardMax ${r.hardMax}`);
  r.sections.forEach((s, i) => {
    assert.equal(s.number, i + 1);
    assert.ok(s.text.length > 0);
  });
  return r;
}

test('target validation', () => {
  assert.equal(S.validateTarget(2900).ok, true);
  assert.equal(S.validateTarget('2900').value, 2900);
  for (const bad of ['', null, undefined, 'abc', 99, 0, -5, 1.5, 100001, NaN, Infinity]) {
    const v = S.validateTarget(bad);
    assert.equal(v.ok, false, 'should reject ' + String(bad));
    assert.ok(v.error);
  }
  const r = S.splitText('hello', 5);
  assert.equal(r.ok, false);
  assert.deepEqual(r.sections, []);
});

test('empty and whitespace-only input gives no sections', () => {
  for (const t of ['', '   ', '\n\n\t \r\n', null, undefined]) {
    const r = S.splitText(t, 2900);
    assert.equal(r.ok, true);
    assert.equal(r.sections.length, 0);
    assert.equal(r.blank, true);
  }
});

test('short text stays in one section, untouched', () => {
  const t = '  Hello world.  \n';
  const r = checkInvariants(t, 2900);
  assert.equal(r.sections.length, 1);
  assert.equal(r.sections[0].text, t);
});

test('target 2900 never produces sections over 2999', () => {
  const text = 'This is a sentence of moderate length. '.repeat(600);
  const r = checkInvariants(text, 2900);
  assert.ok(r.hardMax <= 2999);
  assert.ok(r.sections.length > 1);
});

test('hardMax stays within 2999 for the 2900 target for all text shapes', () => {
  const shapes = ['word '.repeat(5000), 'a'.repeat(20000), 'Short. '.repeat(3000), 'x, '.repeat(4000)];
  for (const t of shapes) assert.ok(maxLen(checkInvariants(t, 2900)) <= 2999);
});

test('prefers sentence boundaries', () => {
  const text = 'Alpha beta gamma delta. '.repeat(400);
  const r = checkInvariants(text, 1000);
  for (const s of r.sections.slice(0, -1)) {
    assert.match(s.text.trimEnd(), /\.$/, 'each section should end on a full stop');
  }
});

test('falls back to commas when there are no sentence ends', () => {
  const text = 'one two three, '.repeat(500);
  const r = checkInvariants(text, 1000);
  for (const s of r.sections.slice(0, -1)) assert.match(s.text.trimEnd(), /,$/);
});

test('falls back to word boundaries without punctuation', () => {
  const text = 'lorem ipsum dolor sit amet '.repeat(600);
  const r = checkInvariants(text, 1000);
  for (const s of r.sections.slice(0, -1)) {
    assert.ok(/\s$/.test(s.text), 'cut should be after a space so no word is split');
  }
});

test('no punctuation and no spaces: safe hard split, nothing lost', () => {
  const text = 'a'.repeat(10000);
  const r = checkInvariants(text, 2900);
  assert.ok(r.sections.length >= 4);
});

test('strict mode (smart off) never exceeds the exact target', () => {
  const text = 'Strict mode sentence. '.repeat(500);
  const r = checkInvariants(text, 1000, false);
  assert.ok(maxLen(r) <= 1000);
  assert.equal(r.hardMax, 1000);
});

test('decimal numbers and abbreviations are not treated as sentence ends mid-number', () => {
  const text = ('The value is 3.14159 and the total is 2.718. ').repeat(200);
  const r = checkInvariants(text, 500);
  for (const s of r.sections.slice(0, -1)) assert.match(s.text.trimEnd(), /\.$/);
  for (const s of r.sections) assert.ok(!/\d\.$/.test(s.text.slice(0, -1)) || true);
});

test('paragraphs are preserved and preferred as break points', () => {
  const para = 'Paragraph sentence one. Paragraph sentence two. Paragraph sentence three.';
  const text = Array.from({ length: 60 }, () => para).join('\n\n');
  const r = checkInvariants(text, 700);
  for (const s of r.sections.slice(0, -1)) {
    assert.match(s.text, /\n\n\s*$|[.]\s*$/);
  }
  assert.equal(join(r), text);
});

test('whitespace and CRLF line endings are kept exactly', () => {
  const text = ('Line one.\r\n\r\n   Indented line two.\t\r\n').repeat(120);
  checkInvariants(text, 400);
});

test('Unicode: emoji and surrogate pairs are never cut in half', () => {
  const text = '😀'.repeat(3000);
  const r = checkInvariants(text, 1001); // odd size forces mid-pair cut attempts
  for (const s of r.sections) {
    const first = s.text.charCodeAt(0);
    const last = s.text.charCodeAt(s.text.length - 1);
    assert.ok(!(first >= 0xdc00 && first <= 0xdfff), 'section starts with a lone low surrogate');
    assert.ok(!(last >= 0xd800 && last <= 0xdbff), 'section ends with a lone high surrogate');
  }
});

test('Unicode: combining marks stay with their base letter', () => {
  const text = 'e\u0301'.repeat(2000);
  const r = checkInvariants(text, 1001);
  for (const s of r.sections) assert.ok(!/^[\u0300-\u036f]/.test(s.text));
});

test('French text with accents, guillemets and sentence ends', () => {
  const text = ('Bonjour à tous, voici une phrase française très élégante ! « Où est la bibliothèque ? » demanda-t-elle. ').repeat(120);
  const r = checkInvariants(text, 800);
  for (const s of r.sections.slice(0, -1)) assert.match(s.text.trimEnd(), /[.!?»]$/);
});

test('Urdu text splits on the Urdu full stop and question mark', () => {
  const text = ('یہ ایک اردو جملہ ہے۔ کیا آپ کتابیں پڑھتے ہیں؟ مجھے پڑھنا بہت پسند ہے۔ ').repeat(150);
  const r = checkInvariants(text, 600);
  assert.ok(r.sections.length > 1);
  for (const s of r.sections.slice(0, -1)) assert.match(s.text.trimEnd(), /[۔؟]$/);
});

test('Chinese text splits on 。 without spaces', () => {
  const text = '这是一个测试句子。'.repeat(500);
  const r = checkInvariants(text, 300);
  for (const s of r.sections.slice(0, -1)) assert.match(s.text, /。$/);
});

test('quotes after sentence end stay with the sentence', () => {
  const text = ('He said, "Stop right there." Then he left. ').repeat(150);
  const r = checkInvariants(text, 500);
  for (const s of r.sections) assert.ok(!/^["'”’]/.test(s.text), 'closing quote must not start a section');
});

test('one very long sentence is cut at word boundaries', () => {
  const text = 'word '.repeat(3000).trim() + '.';
  checkInvariants(text, 1000);
});

test('minimum and maximum target boundaries work', () => {
  checkInvariants('Some text here. '.repeat(100), 100);
  checkInvariants('Some text here. '.repeat(100), 100000);
  assert.equal(S.splitText('Some text here. '.repeat(100), 100000).sections.length, 1);
});

test('large input finishes quickly (no infinite loop)', () => {
  const text = 'Lorem ipsum dolor sit amet. '.repeat(40000); // ~1.1M chars
  const t0 = Date.now();
  const r = checkInvariants(text, 2900);
  assert.ok(Date.now() - t0 < 5000, 'splitting took too long');
  assert.ok(r.sections.length > 300);
});

test('pseudo-random fuzz: always lossless and within limits', () => {
  let seed = 12345;
  const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
  const alphabet = ['a', 'bb', 'ccc', ' ', ' ', '.', ', ', '\n', '\n\n', '؟', '。', '😀', 'é', '"', '!'];
  for (let n = 0; n < 150; n++) {
    let t = '';
    const len = Math.floor(rnd() * 6000);
    while (t.length < len) t += alphabet[Math.floor(rnd() * alphabet.length)];
    const target = 100 + Math.floor(rnd() * 1500);
    checkInvariants(t, target, rnd() > 0.2);
  }
});

test('counting: characters, no-space, words, paragraphs', () => {
  const t = 'Hello world.\n\nSecond  paragraph here.';
  assert.equal(S.countChars(t), t.length);
  assert.equal(S.countNoSpace(t), t.replace(/\s/g, '').length);
  assert.equal(S.countWords(t), 5);
  assert.equal(S.countParagraphs(t), 2);
  assert.equal(S.countParagraphs(''), 0);
  assert.equal(S.countParagraphs('  \n\n  '), 0);
  assert.equal(S.countWords(''), 0);
  assert.equal(S.countChars('😀a'), 2);
  assert.equal(S.countParagraphs('a\r\n\r\nb'), 2);
});

test('section ids are stable, content-based and distinguish different text', () => {
  assert.equal(S.sectionId('abc'), S.sectionId('abc'));
  assert.notEqual(S.sectionId('abc'), S.sectionId('abd'));
  assert.notEqual(S.sectionId('abc'), S.sectionId('abc '));
  const a = S.splitText('First sentence here. '.repeat(300), 1000);
  const b = S.splitText('First sentence here. '.repeat(300), 1000);
  assert.deepEqual(a.sections.map(s => s.id), b.sections.map(s => s.id));
});

test('joinSections with and without headers', () => {
  const r = S.splitText('A. '.repeat(100), 100);
  const withH = S.joinSections(r.sections, true);
  assert.ok(withH.startsWith('--- SECTION 1 ---\n'));
  assert.ok(withH.includes('--- SECTION 2 ---'));
  const noH = S.joinSections(r.sections, false);
  assert.ok(!noH.includes('--- SECTION'));
});
