'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../www/js/splitter.js');
const T = require('../www/js/tracker.js');
const P = require('../www/js/session.js');

function makeState(text, target = 500) {
  const r = S.splitText(text, target, { smart: true });
  let tracker = T.emptyState();
  if (r.sections.length > 2) tracker = T.recordSectionCopy(tracker, r.sections[2], 1234);
  return { text, target, smart: true, headers: false, splitSource: text, sections: r.sections, tracker };
}
const roundTrip = rec => JSON.parse(JSON.stringify(rec)); // what storage does

const SCRIPT = ('Bonjour à tous. یہ ایک اردو جملہ ہے۔ Plain English sentence number one. ').repeat(200);

test('a saved record restores text, settings, sections and the last-copied marker', () => {
  const st = makeState(SCRIPT);
  const rec = roundTrip(P.build(st, 7, 1000));
  const v = P.validate(rec);
  assert.equal(v.ok, true);
  assert.equal(v.record.text, SCRIPT);
  assert.equal(v.record.target, '500');
  assert.equal(v.record.headers, false);
  assert.equal(v.record.sectionCount, st.sections.length);
  const rs = P.restoreSections(v, v.record);
  assert.equal(rs.sections.length, st.sections.length);
  assert.deepEqual(rs.sections.map(s => s.text), st.sections.map(s => s.text));
  assert.deepEqual(rs.sections.map(s => s.id), st.sections.map(s => s.id));
  assert.equal(v.record.tracker.lastSection.number, 3);
  const rc = T.reconcile(v.record.tracker, rs.sections, 'x');
  assert.equal(rc.section.status, 'active');
  assert.equal(rc.section.index, 2);
});

test('split source is stored only when it differs from the current text', () => {
  const st = makeState(SCRIPT);
  assert.equal(P.build(st, 1, 1).splitIsText, true);
  assert.equal(P.build(st, 1, 1).splitSource, null);
  const edited = Object.assign({}, st, { text: SCRIPT + ' edited after split' });
  const rec = roundTrip(P.build(edited, 2, 2));
  assert.equal(rec.splitIsText, false);
  assert.equal(rec.splitSource, SCRIPT);
  const v = P.validate(rec);
  assert.equal(v.ok, true);
  const rs = P.restoreSections(v, v.record);
  assert.equal(rs.splitSource, SCRIPT);
  assert.equal(rs.sections.length, st.sections.length);
});

test('no split yet: record has no sections', () => {
  const rec = roundTrip(P.build({ text: 'just typing', target: '2900', smart: true, headers: true, splitSource: null, sections: [], tracker: null }, 1, 1));
  const v = P.validate(rec);
  assert.equal(v.ok, true);
  assert.equal(P.restoreSections(v, v.record).sections.length, 0);
});

test('tampered or truncated text is rejected by the checksum', () => {
  const rec = roundTrip(P.build(makeState(SCRIPT), 3, 3));
  const bad = Object.assign({}, rec, { text: rec.text.slice(0, -10) });
  assert.equal(P.validate(bad).ok, false);
  const bad2 = Object.assign({}, rec, { seq: 99 });
  assert.equal(P.validate(bad2).ok, false);
  assert.equal(P.validate(null).ok, false);
  assert.equal(P.validate('garbage').ok, false);
  assert.equal(P.validate({}).ok, false);
  assert.equal(P.validate(Object.assign({}, rec, { v: 1 })).ok, false);
});

test('damaged sections are dropped but the text is still restored', () => {
  const rec = roundTrip(P.build(makeState(SCRIPT), 3, 3));
  rec.sections[1].text = rec.sections[1].text.slice(1); // damage one section, checksum uses ids so record stays valid
  const v = P.validate(rec);
  assert.equal(v.ok, true);
  const rs = P.restoreSections(v, v.record);
  assert.equal(rs.sections.length, 0);
  assert.equal(rs.damaged, true);
  assert.equal(v.record.text, SCRIPT);
});

test('pickBest chooses the highest sequence among valid candidates and ignores invalid ones', () => {
  const mk = (seq, text) => P.validate(roundTrip(P.build({ text, target: '500', smart: true, headers: true, splitSource: null, sections: [], tracker: null }, seq, seq)));
  const corrupt = { ok: false, reason: 'x' };
  const best = P.pickBest([mk(4, 'four'), corrupt, mk(5, 'five'), mk(3, 'three')]);
  assert.equal(best.record.text, 'five');
  assert.equal(P.pickBest([corrupt, null]), null);
  assert.equal(P.pickBest([]), null);
});

test('slots alternate A/B so the previous good copy is never overwritten', () => {
  assert.equal(P.slotFor(1), 'B');
  assert.equal(P.slotFor(2), 'A');
  assert.notEqual(P.slotFor(10), P.slotFor(11));
});

test('empty session (cleared) is a valid tombstone record', () => {
  const rec = roundTrip(P.build({ text: '', target: '2900', smart: true, headers: true, splitSource: null, sections: [], tracker: null }, 9, 9));
  const v = P.validate(rec);
  assert.equal(v.ok, true);
  assert.equal(v.record.text, '');
});

test('very long script (2 million characters) survives a JSON round trip unchanged', () => {
  const big = 'Lorem ipsum dolor sit amet, consectetur. نص عربي طويل. Texte français éèà. '.repeat(27000);
  assert.ok(big.length > 2000000);
  const st = makeState(big, 2900);
  const json = JSON.stringify(P.build(st, 12, 12));
  const v = P.validate(JSON.parse(json));
  assert.equal(v.ok, true);
  assert.equal(v.record.text.length, big.length);
  assert.equal(v.record.text, big);
  const rs = P.restoreSections(v, v.record);
  assert.equal(rs.sections.length, st.sections.length);
  assert.equal(rs.sections.map(s => s.text).join(''), big);
});

test('settings values keep their exact form', () => {
  const rec = roundTrip(P.build({ text: 'x', target: '', smart: false, headers: false, splitSource: null, sections: [], tracker: null }, 1, 1));
  const v = P.validate(rec).record;
  assert.equal(v.target, '');
  assert.equal(v.smart, false);
  assert.equal(v.headers, false);
});
