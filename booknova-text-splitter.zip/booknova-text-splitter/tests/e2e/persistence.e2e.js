/*
 * End-to-end persistence test (not part of `npm test`: it needs Playwright + Chromium).
 *   PLAYWRIGHT_PATH=/path/to/node_modules/playwright CHROME_PATH=/path/to/chrome node tests/e2e/persistence.e2e.js
 * It serves www/ over HTTP, drives the real app, and kills the browser process with SIGKILL to imitate
 * Android removing the app from recent apps / killing its process.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');
const assert = require('assert');

const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const CHROME = process.env.CHROME_PATH || undefined;
const WWW = path.join(__dirname, '..', '..', 'www');

const server = http.createServer((req, res) => {
  const p = path.join(WWW, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
  fs.readFile(p, (err, data) => {
    if (err) { res.writeHead(404); res.end(); return; }
    const ext = path.extname(p);
    res.writeHead(200, { 'Content-Type': { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' }[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

// A realistic long script with paragraphs, French and Urdu.
function longScript() {
  const parts = [];
  for (let i = 1; i <= 90; i++) {
    parts.push(`Chapitre ${i}. Voici une phrase française très élégante, avec des accents éèà ! Où est la bibliothèque ? ` +
      `This is English sentence number ${i}, followed by another one. یہ ایک اردو جملہ ہے۔ کیا آپ کتابیں پڑھتے ہیں؟ ` +
      'The quick brown fox jumps over the lazy dog many times. '.repeat(3));
  }
  return parts.join('\n\n');
}

const MOCK_NATIVE = () => {
  // Imitates the Capacitor Android plugins so the native code paths run in a normal browser.
  window.__writes = 0;
  const delay = Number(sessionStorage.getItem('mockDelay') || 0) || (window.__MOCK_DELAY || 0);
  const wait = () => new Promise(r => setTimeout(r, window.__MOCK_DELAY || 0));
  window.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {
      Filesystem: {
        writeFile: async o => { await wait(); window.__writes++; localStorage.setItem('mockfs:' + o.path, o.data); return { uri: 'file://' + o.path }; },
        readFile: async o => { await wait(); const v = localStorage.getItem('mockfs:' + o.path); if (v === null) throw new Error('File does not exist.'); return { data: v }; },
        deleteFile: async o => { localStorage.removeItem('mockfs:' + o.path); }
      },
      Preferences: {
        get: async ({ key }) => { await wait(); return { value: localStorage.getItem('mockpref:' + key) }; },
        set: async ({ key, value }) => { window.__writes++; localStorage.setItem('mockpref:' + key, value); },
        remove: async ({ key }) => { localStorage.removeItem('mockpref:' + key); }
      },
      Clipboard: { write: async ({ string }) => { window.__clip = string; }, read: async () => ({ value: '' }) },
      App: { addListener() {}, exitApp() {} },
      Share: { share: async () => ({}) }
    }
  };
};

let step = 0;
const ok = msg => console.log(`  ✓ ${++step}. ${msg}`);

async function launch(profile, opts = {}) {
  const ctx = await chromium.launchPersistentContext(profile, {
    executablePath: CHROME, args: ['--no-sandbox'], viewport: { width: 390, height: 800 },
    permissions: ['clipboard-read', 'clipboard-write']
  });
  if (opts.native) {
    await ctx.addInitScript(`window.__MOCK_DELAY = ${opts.delay || 0};`);
    await ctx.addInitScript(MOCK_NATIVE);
  }
  const page = ctx.pages()[0] || await ctx.newPage();
  page.on('pageerror', e => { throw e; });
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  if (!opts.noWait) await page.waitForSelector('html[data-ready="1"]', { timeout: 20000 });
  return { ctx, page };
}

function killHard(profile) {
  // SIGKILL every Chromium process that uses this profile: no shutdown hooks, no flush.
  try { execSync(`pkill -9 -f "${profile}"`); } catch (e) { /* none left */ }
}

async function state(page) {
  return page.evaluate(() => ({
    text: document.getElementById('sourceText').value,
    chars: document.getElementById('charCount').textContent,
    noSpace: document.getElementById('noSpaceCount').textContent,
    words: document.getElementById('wordCount').textContent,
    paras: document.getElementById('paragraphCount').textContent,
    target: document.getElementById('targetSize').value,
    smart: document.getElementById('smartMode').checked,
    headers: document.getElementById('headerMode').checked,
    sections: [...document.querySelectorAll('.chunk-body')].map(e => e.textContent),
    badges: [...document.querySelectorAll('.chunk')].map((c, i) => ({ n: i + 1, shown: !c.querySelector('.badge').hidden, text: c.querySelector('.badge').textContent })).filter(b => b.shown),
    lastTitle: document.getElementById('lastTitle').textContent,
    status: document.getElementById('saveStatus').textContent,
    summary: document.getElementById('resultSummary').textContent
  }));
}
const savedFlag = page => page.waitForFunction(() => /^Saved ✓/.test(document.getElementById('saveStatus').textContent), null, { timeout: 15000 });

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'bn-e2e-'));

  /* ===== Scenario 1: the required user journey, with SIGKILL between sessions ===== */
  console.log('Scenario 1: paste, split, copy section 3, kill the app, reopen');
  const prof1 = path.join(root, 'profile-web');
  let { ctx, page } = await launch(prof1);
  const SCRIPT = longScript();
  await page.fill('#sourceText', SCRIPT);
  await page.fill('#targetSize', '2500');
  await page.uncheck('#headerMode');
  await page.click('#splitBtn');
  await page.waitForSelector('.chunk');
  await page.locator('.chunk-copy').nth(2).click();
  await page.waitForFunction(() => document.querySelectorAll('.badge:not([hidden])').length === 1);
  await savedFlag(page);
  const before = await state(page);
  assert.ok(before.sections.length >= 10, 'long script should give many sections');
  assert.deepStrictEqual(before.badges.map(b => b.n), [3]);
  assert.strictEqual(before.badges[0].text, 'LAST COPIED ✓');
  ok(`section 3 of ${before.sections.length} is marked LAST COPIED and the status says "${before.status}"`);
  assert.strictEqual(before.sections.join(''), SCRIPT);
  ok('sections join back to the exact original text');

  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  let after = await state(page);
  assert.strictEqual(after.text, SCRIPT, 'text restored exactly');
  ok(`original text restored exactly (${after.text.length.toLocaleString()} characters)`);
  assert.deepStrictEqual([after.chars, after.noSpace, after.words, after.paras], [before.chars, before.noSpace, before.words, before.paras]);
  ok(`counters restored: ${after.chars} chars / ${after.noSpace} no-space / ${after.words} words / ${after.paras} paragraphs`);
  assert.deepStrictEqual(after.sections, before.sections);
  assert.strictEqual(after.summary, before.summary);
  ok(`all ${after.sections.length} split sections restored without pressing Split again`);
  assert.deepStrictEqual([after.target, after.smart, after.headers], ['2500', true, false]);
  ok('settings restored (target 2500, smart on, headers off)');
  assert.deepStrictEqual(after.badges.map(b => b.n), [3]);
  assert.strictEqual(after.badges[0].text, 'LAST COPIED ✓');
  assert.ok(/Section 3/.test(after.lastTitle));
  ok('LAST COPIED marker is still on Section 3');

  await page.locator('.chunk-copy').nth(3).click();
  await page.waitForFunction(() => { const b = [...document.querySelectorAll('.badge:not([hidden])')]; return b.length === 1 && b[0].closest('.chunk').id === 'section-4'; });
  await savedFlag(page);
  ok('can keep working: copying Section 4 moves the marker to Section 4');
  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  after = await state(page);
  assert.deepStrictEqual(after.badges.map(b => b.n), [4]);
  ok('after a second kill and reopen the marker is on Section 4 only');

  /* Copy All state survives too */
  await page.click('#copyAllBtn');
  await page.waitForFunction(() => /ALL sections/.test(document.getElementById('lastTitle').textContent));
  await savedFlag(page);
  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  after = await state(page);
  assert.ok(/ALL sections/.test(after.lastTitle));
  assert.deepStrictEqual(after.badges.map(b => b.n), [4]);
  assert.strictEqual(after.badges[0].text, 'LAST SECTION COPIED ✓');
  ok('Copy All state restored without marking any section as the Copy All target');

  /* Clear All needs confirmation */
  await page.click('#clearBtn');
  assert.ok(await page.locator('#clearModal').isVisible());
  ok('Clear all opens a confirmation dialog');
  await page.click('#clearCancel');
  assert.ok(!(await page.locator('#clearModal').isVisible()));
  assert.strictEqual((await state(page)).text, SCRIPT);
  await page.reload(); await page.waitForSelector('html[data-ready="1"]');
  assert.strictEqual((await state(page)).text, SCRIPT);
  ok('Cancel keeps everything, even after a reload');
  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  assert.strictEqual((await state(page)).sections.length, before.sections.length);
  ok('data stays saved until the user clears it');

  await page.click('#clearBtn');
  await page.click('#clearConfirm');
  await page.waitForFunction(() => document.getElementById('sourceText').value === '');
  await page.waitForFunction(() => /Saved data deleted/.test(document.getElementById('saveStatus').textContent), null, { timeout: 15000 });
  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  after = await state(page);
  assert.strictEqual(after.text, '');
  assert.strictEqual(after.sections.length, 0);
  assert.strictEqual(after.badges.length, 0);
  ok('after confirming Clear all, a restart shows an empty session');

  /* Auto-save while typing (no Split pressed, no button pressed) */
  await page.click('#sourceText');
  await page.keyboard.type('Typed by hand, never split. Second sentence here.');
  await page.waitForTimeout(900);
  killHard(prof1);
  await new Promise(r => setTimeout(r, 800));
  ({ ctx, page } = await launch(prof1));
  after = await state(page);
  assert.strictEqual(after.text, 'Typed by hand, never split. Second sentence here.');
  assert.strictEqual(after.sections.length, 0);
  ok('text typed by hand is auto-saved and restored after a kill (no Split, no Save button)');
  await ctx.close();

  /* ===== Scenario 2: Android storage layer (mocked plugins): file copy + corruption fallback ===== */
  console.log('Scenario 2: second copy in private file storage, corrupted newest copy');
  const prof2 = path.join(root, 'profile-native');
  ({ ctx, page } = await launch(prof2, { native: true }));
  await page.fill('#sourceText', 'Version one of my script. '.repeat(120));
  await page.click('#splitBtn');
  await page.waitForSelector('.chunk');
  await page.locator('.chunk-copy').nth(0).click();
  await savedFlag(page);
  assert.ok((await page.evaluate(() => window.__clip)).length > 0);
  ok('native clipboard plugin path used for copying');
  const v1 = await state(page);
  await page.fill('#sourceText', 'Version two of my script, edited later. '.repeat(80));
  await page.waitForTimeout(900); await savedFlag(page);
  await ctx.close();

  // wipe the whole IndexedDB: the file copy alone must restore the session
  ({ ctx, page } = await launch(prof2, { native: true, noWait: true }));
  await page.waitForSelector('html[data-ready="1"]');
  await page.evaluate(() => new Promise(res => { const r = indexedDB.deleteDatabase('booknova-db'); r.onsuccess = r.onerror = r.onblocked = () => res(); }));
  await page.reload(); await page.waitForSelector('html[data-ready="1"]');
  let s2 = await state(page);
  assert.ok(s2.text.startsWith('Version two'), 'file copy restores the latest text');
  assert.ok(/Restored/.test(s2.status));
  ok('with IndexedDB wiped, the private-file copy restores the latest work');
  await ctx.close();

  // corrupt the NEWEST copy in both stores: the older good copy must be used
  ({ ctx, page } = await launch(prof2, { native: true }));
  await page.fill('#sourceText', 'Version three. '.repeat(100));
  await page.waitForTimeout(900); await savedFlag(page);
  await page.evaluate(async () => {
    const db = await new Promise(r => { const q = indexedDB.open('booknova-db', 1); q.onsuccess = () => r(q.result); });
    const get = k => new Promise(r => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => r(q.result); });
    const put = (k, v) => new Promise(r => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = r; });
    const a = await get('slotA'), b = await get('slotB');
    const newest = (a && (!b || a.seq > b.seq)) ? 'A' : 'B';
    const rec = newest === 'A' ? a : b;
    rec.text = rec.text.slice(0, -5);            // truncated text, checksum no longer matches
    await put('slot' + newest, rec);
    const key = 'mockfs:booknova-session-' + newest + '.json';
    const f = JSON.parse(localStorage.getItem(key)); f.text = f.text.slice(0, -5);
    localStorage.setItem(key, JSON.stringify(f));
  });
  await ctx.close();
  ({ ctx, page } = await launch(prof2, { native: true }));
  s2 = await state(page);
  assert.ok(s2.text.startsWith('Version two'), 'falls back to the previous good copy, got: ' + s2.text.slice(0, 20));
  ok('a truncated/corrupted newest copy is rejected and the previous good copy is restored');
  await ctx.close();

  /* ===== Scenario 3: nothing may overwrite saved work during start-up ===== */
  console.log('Scenario 3: start-up guard (slow storage, app sent to background while loading)');
  const prof3 = path.join(root, 'profile-guard');
  ({ ctx, page } = await launch(prof3, { native: true }));
  await page.fill('#sourceText', 'Precious script that must never be lost. '.repeat(60));
  await page.waitForTimeout(900); await savedFlag(page);
  await ctx.close();

  ({ ctx, page } = await launch(prof3, { native: true, delay: 600, noWait: true }));
  await page.waitForTimeout(300);
  assert.ok(await page.locator('#sourceText').isDisabled());
  await page.evaluate(() => {
    window.dispatchEvent(new Event('blur'));
    window.dispatchEvent(new Event('pagehide'));
    Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
    document.dispatchEvent(new Event('visibilitychange'));
    Object.defineProperty(document, 'hidden', { configurable: true, get: () => false });
  });
  const writesWhileLoading = await page.evaluate(() => window.__writes);
  assert.strictEqual(writesWhileLoading, 0, 'no write may happen before restore completes');
  ok('input is locked and zero writes happen while saved data is still loading');
  await page.waitForSelector('html[data-ready="1"]', { timeout: 30000 });
  assert.ok((await state(page)).text.startsWith('Precious script'));
  await ctx.close();
  ({ ctx, page } = await launch(prof3, { native: true }));
  assert.ok((await state(page)).text.startsWith('Precious script'));
  ok('saved work is intact after the slow start-up');
  await ctx.close();

  fs.rmSync(root, { recursive: true, force: true });
  server.close();
  console.log(`\nAll persistence checks passed (${step}).`);
})().catch(e => { console.error('\nFAILED:', e && e.stack || e); try { server.close(); } catch (x) {} process.exit(1); });
