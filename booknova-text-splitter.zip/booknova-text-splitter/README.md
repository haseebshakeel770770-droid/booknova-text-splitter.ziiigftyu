# BookNova Text Counter & Smart Splitter

An offline Android app (Capacitor) that counts characters, words and paragraphs, splits long scripts into
sentence-aware sections, and remembers which section you copied last. Built from the original `Text count.html`
(kept in `original/`), with the same dark BookNova look.

- App ID: `com.booknova.textsplitter`
- No internet, no server, **no Android permissions**. Everything is stored on the device.

## What it does

| Feature | Details |
|---|---|
| Counters | Characters with spaces, characters without whitespace, words, paragraphs (emoji count as one character) |
| Smart splitting | Prefers sentence ends (`. ! ? … 。 ！ ？ ؟ ۔` and blank lines), then `, ; : ، ؛` and line breaks, then spaces, then a safe hard cut. Never cuts inside an emoji or a letter with its accent. |
| Size limit | Target 2900 gives sections of at most 2998 characters (never above 2999). Target must be 100 to 100,000. |
| Lossless | Joining all sections gives back your exact text (spaces, line breaks, paragraphs included). |
| Strict mode | Untick "Keep sentence boundaries" to cut at exactly the target size. |
| Copy | One button per section, plus Copy all. Success is shown only if the copy really worked; otherwise a manual-copy box opens. |
| **Last Copied** | The most recently copied section gets a `LAST COPIED ✓` badge. Copying another section moves it. The state is saved on the device. |
| Copy all | Has its own indicator (`LAST COPIED ✓` on the Copy all button and in the summary bar). It never puts a badge on a single section. |
| Edits | The marker follows the *content* (a fingerprint of the section text), not just its number. If the text no longer matches, the marker is removed instead of pointing at the wrong section. |
| History | "Copy history" lists the last 10 copies. |
| Save .txt | Opens the Android share sheet so you can save to Files/Drive or send it anywhere. |
| Auto-save and restore | Everything is saved automatically while you type and restored when you reopen the app (see "How saving works"). |
| Clear all | Asks for confirmation first (Cancel is the default). Nothing is deleted unless you confirm. |
| Back button | Closes dialogs first, then scrolls to top, then asks you to press back again to exit. |

## How saving works

Saving is automatic. There is no Save button and nothing is sent anywhere: all data stays on the phone.

- **What is saved:** your full text, target size, smart/strict mode, header option, the generated sections and
  their count, the Last Copied marker (section number, content fingerprint, time), the Copy All state and the copy history.
- **When:** about half a second after you stop typing or pasting, immediately after Split and after every copy,
  and instantly when the app goes to the background, loses focus or closes.
- **Where:** three places, so one failing cannot lose your work:
  1. IndexedDB inside the app (main copy; handles very long scripts, tested with 1.6 million characters).
  2. A JSON file in the app's private storage (Capacitor Filesystem, `Directory.Data`).
  3. Capacitor Preferences for the small settings and marker.
- **Crash safety:** the session is written to two alternating slots (A and B) with a checksum, so a new save never
  overwrites the last good copy. On start the newest copy that passes its checksum is used. A damaged copy is skipped.
- **Start-up safety:** the text box is locked until saved data has been read, and nothing can be saved before that,
  so an empty screen can never overwrite your work. If storage cannot be read, the app says so instead of showing a blank session.
- **Lifetime:** data stays until you press **Clear all** and confirm, or clear the app's data in Android settings.
  App updates keep it (the app ID stays the same). Data from version 1 of this app is migrated automatically.
- **Status:** the small label next to "Your text" shows `Saving…`, `Saved ✓ time` or a warning if saving fails.
- **Privacy:** `allowBackup` is off and there are no network permissions, so scripts are not copied to Google Drive or any server.

## Project layout

```
www/                    The app (HTML, CSS, JS). Runs inside the Android WebView.
  index.html
  css/styles.css
  js/splitter.js        Splitting and counting logic (pure, tested)
  js/tracker.js         Last-copied logic (pure, tested)
  js/session.js         Saved-session format, checksums, picking the newest good copy (pure, tested)
  js/storage.js         Permanent storage: IndexedDB + private file + Preferences
  js/native.js          Clipboard, file share and back button bridge
  js/app.js             UI
tests/                  Node tests (splitter, tracker, session) and tests/e2e (browser persistence test)
android/                Native Android project (Gradle)
capacitor.config.json   App ID, name, web folder
package.json
.github/workflows/
  android-debug.yml     Builds the debug APK on every push / manually
  android-release.yml   Optional signed release APK (needs secrets)
original/Text count.html  Your original file
```

## Run the tests

```
npm install
npm test            # 48 logic tests (splitter, last-copied tracker, saved-session format)
```

Persistence end-to-end test (needs Playwright and Chromium; it also kills the browser with SIGKILL between sessions):

```
PLAYWRIGHT_PATH=/path/to/node_modules/playwright CHROME_PATH=/path/to/chrome node tests/e2e/persistence.e2e.js
```

It covers: paste, split, copy Section 3, kill, reopen, restore of text/counters/sections/settings/marker, continuing to copy,
Copy All state, Clear all Cancel and Confirm, typing auto-save, IndexedDB wiped (file copy restores), a corrupted newest
copy (older copy restores), and the start-up overwrite guard.

## Build the APK on GitHub (no Android Studio needed)

1. Create a new GitHub repository (private is fine).
2. Upload **all files and folders of this project**, including the hidden `.github` folder (see "Uploading" below).
3. Open the **Actions** tab. The workflow **Build Android APK (debug)** starts by itself after your push.
   To start it manually: Actions, **Build Android APK (debug)**, **Run workflow**.
4. Wait for the green tick (about 5 to 10 minutes the first time).
5. Open the finished run and scroll to **Artifacts**. Download **BookNova-Text-Splitter-debug-apk**.
   It is a ZIP containing `BookNova-Text-Splitter-debug.apk`.
6. Unzip it on your phone, tap the APK and allow "Install unknown apps" for your file manager or browser when asked.

**GitHub Release (optional):** push a tag such as `v1.0.0` and the same workflow also attaches the APK to a
Release, which gives a direct download link.

### What the workflow does, in plain words

1. Downloads your code onto a temporary GitHub computer.
2. Installs Node.js, Java 17, the Android SDK and Gradle 8.2.1.
3. Runs `npm install` to fetch Capacitor and its plugins.
4. Runs the logic tests. If a test fails, the build stops.
5. Runs `npx cap sync android`, which copies `www/` into the Android project.
6. Runs `gradle assembleDebug` to build the app.
7. Finds the APK under `android/app/build/outputs/apk/debug/` and uploads it as a downloadable artifact.

## Debug APK vs signed release APK

- **Debug APK**: signed automatically with a temporary debug key. Installs on any phone you allow, no setup. Good for
  personal use and testing. It cannot be uploaded to Google Play.
- **Release APK**: signed with *your own* private key. Needed for Google Play and for updates that install over
  each other reliably. Keep that key safe: if you lose it you cannot update the app under the same identity.

### Signed release APK (optional)

1. Create a keystore (on a computer with Java):
   `keytool -genkeypair -v -keystore release.keystore -alias booknova -keyalg RSA -keysize 2048 -validity 10000`
2. Convert it to text: `base64 -w0 release.keystore` (macOS: `base64 -i release.keystore`).
3. In GitHub: Settings, Secrets and variables, Actions, add these secrets:
   `KEYSTORE_BASE64` (the text from step 2), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (for example `booknova`), `KEY_PASSWORD`.
4. Actions, **Build signed release APK (optional)**, Run workflow. Download **BookNova-Text-Splitter-release-apk**.

Never commit the keystore file. The `.gitignore` already blocks `*.keystore` and `*.jks`.

## Uploading to GitHub

**From a computer (easiest):** unzip the project, open your new repository, click **Add file, Upload files**, drag in
everything inside the project folder (the folders `www`, `android`, `tests`, `.github`, `original`, `resources` and the
loose files), then **Commit changes**. If your system hides folders that start with a dot, turn on "show hidden files" so
`.github` is included. Alternatively use git:

```
cd booknova-text-splitter
git init && git add . && git commit -m "BookNova Text Splitter"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/YOUR-REPO.git
git push -u origin main
```

**From a phone:** the GitHub website on a phone cannot upload whole folders, and file pickers often hide `.github`.
Two reliable options:
- Use the browser's "Desktop site" mode on github.com and upload folder contents in batches, then create the workflow
  files with **Add file, Create new file**, typing the name `.github/workflows/android-debug.yml` and pasting the file contents.
- Or use Termux (Android) with `pkg install git`, then the git commands above.

## Troubleshooting

- **Workflow does not start:** open Actions and click "I understand my workflows, enable them", then Run workflow.
- **No `.github` folder in the repository:** the workflow files were not uploaded, so add them as described above.
- **Build fails in the Gradle step:** open the failed run, expand "Build the debug APK" and send me the red error lines.
- **Android blocks the install:** allow "Install unknown apps" for the app you opened the APK from.
- **Clipboard blocked on a device:** the app opens a manual-copy box and does not mark anything as copied.

## Notes for developers

- Capacitor 6 (Java 17, Gradle 8.2.1, Android Gradle Plugin 8.2.1, compileSdk/targetSdk 34, minSdk 22).
- The web app uses no bundler. Native plugins are called through `window.Capacitor.Plugins`.
- `android/capacitor.settings.gradle`, `android/app/capacitor.build.gradle` and the web assets are regenerated by `npx cap sync android`.
- To run locally: `npm install && npx cap sync android && cd android && gradle assembleDebug`
  (APK: `android/app/build/outputs/apk/debug/app-debug.apk`).
