package com.booknova.textsplitter;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
