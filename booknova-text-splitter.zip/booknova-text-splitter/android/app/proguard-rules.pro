# Add project specific ProGuard rules here.
# Release builds currently run with minifyEnabled false.
