/*
 * BookNova Text Counter & Smart Splitter - core text logic.
 * Pure functions, no DOM access, so it runs in the app and in Node tests.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BookNovaSplitter = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const MIN_TARGET = 100;
  const MAX_TARGET = 100000;
  const MIN_FILL = 0.4; // a smart cut should fill at least 40% of the target

  // Sentence enders. CJK enders need no following space.
  const SENTENCE_END = new Set(['.', '!', '?', '…', '。', '！', '？', '؟', '۔']);
  const CJK_END = new Set(['。', '！', '？']);
  // Characters that may legitimately close a sentence: quotes and brackets.
  const CLOSERS = new Set(['"', "'", ')', ']', '}', '»', '”', '’', '」', '』', '）']);
  // Softer boundaries used when no sentence end is available.
  const SOFT_BREAK = new Set([',', ';', ':', '،', '؛', '、', '，', '；', '：']);

  const isSpace = ch => ch !== undefined && /\s/.test(ch);

  /** Allowed overshoot above the target. 2900 -> 2998, so never above 2999. */
  function toleranceFor(target) {
    return Math.min(99, Math.max(10, Math.floor(target * 0.034)));
  }

  function validateTarget(value) {
    if (value === '' || value === null || value === undefined) {
      return { ok: false, error: 'Enter a target number of characters.' };
    }
    const n = typeof value === 'number' ? value : Number(String(value).trim());
    if (!Number.isFinite(n)) return { ok: false, error: 'The target must be a number.' };
    if (!Number.isInteger(n)) return { ok: false, error: 'The target must be a whole number.' };
    if (n < MIN_TARGET) return { ok: false, error: 'The target must be at least ' + MIN_TARGET + ' characters.' };
    if (n > MAX_TARGET) return { ok: false, error: 'The target must be ' + MAX_TARGET.toLocaleString('en-US') + ' characters or fewer.' };
    return { ok: true, value: n };
  }

  /** Unicode-aware character count (an emoji counts as one). */
  function countChars(text) {
    let n = 0;
    for (const _ch of text) n++;
    return n;
  }
  function countNoSpace(text) { return countChars(text.replace(/\s/g, '')); }
  function countWords(text) {
    const m = text.match(/\S+/g);
    return m ? m.length : 0;
  }
  function countParagraphs(text) {
    if (!text.trim()) return 0;
    return text.split(/\r?\n[^\S\r\n]*\r?\n/).filter(p => p.trim()).length;
  }

  /** Stable content id: length + 53-bit cyrb53 hash. Same text -> same id. */
  function sectionId(text) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761);
      h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    const hash = (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
    return text.length + ':' + hash;
  }

  /** Move a cut position backwards so it never splits a surrogate pair or a combined character. */
  function safeCut(text, pos, start) {
    let guard = 0;
    while (pos > start + 1 && pos < text.length && guard++ < 16) {
      const code = text.charCodeAt(pos);
      const prev = text.charCodeAt(pos - 1);
      const splitsPair = code >= 0xdc00 && code <= 0xdfff && prev >= 0xd800 && prev <= 0xdbff;
      const continues = /^[\p{M}\u200D\uFE0F\u{1F3FB}-\u{1F3FF}]/u.test(text.slice(pos, pos + 2)) || prev === 0x200d;
      if (splitsPair || continues) pos--; else break;
    }
    return pos;
  }

  /** Choose where the section that begins at `start` should end (exclusive index). */
  function findCut(text, start, target, hardMax, smart) {
    const len = text.length;
    const limit = Math.min(len, start + hardMax);
    if (!smart) return Math.max(start + 1, safeCut(text, Math.min(len, start + target), start));

    const minPos = start + Math.floor(target * MIN_FILL);
    let sentence = -1, soft = -1, word = -1;
    const eatSpace = pos => { while (pos < limit && isSpace(text[pos])) pos++; return pos; };

    for (let i = start; i < limit; i++) {
      const ch = text[i];
      if (SENTENCE_END.has(ch)) {
        let j = i + 1;
        while (j < len && CLOSERS.has(text[j])) j++;
        const ends = CJK_END.has(ch) || j >= len || isSpace(text[j]);
        if (ends && j <= limit) {
          const pos = eatSpace(j);
          if (pos >= minPos) sentence = pos;
        }
      } else if (ch === '\n') {
        let k = i - 1;
        while (k >= start && (text[k] === '\r' || text[k] === ' ' || text[k] === '\t')) k--;
        if (k >= start && text[k] === '\n') { // blank line = paragraph break
          const pos = eatSpace(i + 1);
          if (pos >= minPos) sentence = pos;
        } else {
          const pos = eatSpace(i + 1);
          if (pos >= minPos) soft = pos;
        }
      } else if (SOFT_BREAK.has(ch)) {
        const pos = eatSpace(i + 1);
        if (pos >= minPos) soft = pos;
      }
      if (isSpace(ch)) {
        const pos = eatSpace(i + 1);
        if (pos > start) word = pos;
      }
    }
    let cut = sentence > start ? sentence : soft > start ? soft : word > start ? word : limit;
    cut = Math.min(cut, limit);
    return Math.max(start + 1, safeCut(text, cut, start));
  }

  function hardSplit(text, size) {
    const out = [];
    let start = 0;
    while (start < text.length) {
      const end = Math.max(start + 1, safeCut(text, Math.min(text.length, start + size), start));
      out.push(text.slice(start, end));
      start = end;
    }
    return out;
  }

  /**
   * Split text into sections.
   * Returns { ok, error?, blank?, sections: [{number,text,chars,words,id}], target, hardMax, smart }.
   * Guarantee: sections.map(s => s.text).join('') === text, and no section exceeds hardMax.
   */
  function splitText(input, targetValue, options) {
    const smart = !options || options.smart !== false;
    const check = validateTarget(targetValue);
    if (!check.ok) return { ok: false, error: check.error, sections: [] };
    const target = check.value;
    const text = typeof input === 'string' ? input : '';
    const hardMax = smart ? target + toleranceFor(target) : target;

    if (!text.trim()) return { ok: true, blank: true, sections: [], target, hardMax, smart };

    let parts = [];
    let start = 0;
    let guard = 0;
    const maxIterations = text.length + 5; // every loop advances at least 1 character
    while (start < text.length && guard++ < maxIterations) {
      if (text.length - start <= hardMax) { parts.push(text.slice(start)); start = text.length; break; }
      const end = findCut(text, start, target, hardMax, smart);
      parts.push(text.slice(start, end));
      start = end;
    }
    // Safety net: if anything ever went wrong, fall back to plain safe splitting.
    if (start < text.length || parts.join('') !== text || parts.some(p => p.length > hardMax)) {
      parts = hardSplit(text, target);
    }
    // A last section made only of whitespace is attached to the previous one when it fits.
    if (parts.length > 1 && !parts[parts.length - 1].trim()) {
      const tail = parts.pop();
      if (parts[parts.length - 1].length + tail.length <= hardMax) parts[parts.length - 1] += tail;
      else parts.push(tail);
    }
    const sections = parts.map((t, i) => ({
      number: i + 1, text: t, chars: countChars(t), words: countWords(t), id: sectionId(t)
    }));
    return { ok: true, sections, target, hardMax, smart };
  }

  /** Text used by "Copy all" and the .txt download. */
  function joinSections(sections, withHeaders) {
    if (!withHeaders) return sections.map(s => s.text).join('\n\n');
    return sections.map(s => '--- SECTION ' + s.number + ' ---\n' + s.text).join('\n\n');
  }

  return {
    MIN_TARGET, MAX_TARGET, toleranceFor, validateTarget, countChars, countNoSpace, countWords,
    countParagraphs, sectionId, splitText, joinSections
  };
});
