/*
 * Session record format for permanent local storage. Pure functions (no storage access) so the
 * integrity rules can be unit-tested in Node.
 *
 * A record holds everything needed to continue working: the text, settings, the generated sections
 * and the last-copied tracker. Every record carries a sequence number and a checksum, so a half-written
 * or corrupted copy is detected and ignored in favour of an older good copy.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./splitter.js'), require('./tracker.js'));
  } else {
    root.BookNovaSession = factory(root.BookNovaSplitter, root.BookNovaTracker);
  }
})(typeof self !== 'undefined' ? self : this, function (Splitter, Tracker) {
  'use strict';

  const VERSION = 2;

  function checksum(rec) {
    const ids = Array.isArray(rec.sections) ? rec.sections.map(s => s && s.id).join('|') : '';
    return Splitter.sectionId(JSON.stringify([rec.text, rec.splitSource, rec.splitIsText, ids, rec.seq]));
  }

  /**
   * state: { text, target, smart, headers, splitSource (string|null), sections: [{number,text,id}], tracker }
   */
  function build(state, seq, now) {
    const text = typeof state.text === 'string' ? state.text : '';
    const hasSplit = Array.isArray(state.sections) && state.sections.length > 0 && typeof state.splitSource === 'string';
    const rec = {
      v: VERSION,
      seq: seq,
      savedAt: now,
      text: text,
      target: String(state.target === undefined || state.target === null ? '2900' : state.target),
      smart: state.smart !== false,
      headers: state.headers !== false,
      splitIsText: hasSplit && state.splitSource === text,
      splitSource: hasSplit && state.splitSource !== text ? state.splitSource : null,
      sectionCount: hasSplit ? state.sections.length : 0,
      sections: hasSplit ? state.sections.map(s => ({ number: s.number, text: s.text, id: s.id })) : [],
      tracker: Tracker.sanitize(state.tracker)
    };
    rec.check = checksum(rec);
    return rec;
  }

  /** Returns { ok, record, reason }. Never throws. Sections that fail checks are dropped, not trusted. */
  function validate(raw) {
    try {
      if (!raw || typeof raw !== 'object') return { ok: false, reason: 'not an object' };
      if (typeof raw.v !== 'number' || raw.v < 2 || raw.v > VERSION) return { ok: false, reason: 'unknown version' };
      if (typeof raw.text !== 'string') return { ok: false, reason: 'text missing' };
      if (!Number.isFinite(raw.seq) || !Number.isFinite(raw.savedAt)) return { ok: false, reason: 'bad header' };
      if (typeof raw.check !== 'string' || raw.check !== checksum(raw)) return { ok: false, reason: 'checksum mismatch' };
      const rec = {
        v: raw.v, seq: raw.seq, savedAt: raw.savedAt, text: raw.text,
        target: String(raw.target), smart: raw.smart !== false, headers: raw.headers !== false,
        splitIsText: !!raw.splitIsText,
        splitSource: typeof raw.splitSource === 'string' ? raw.splitSource : null,
        sectionCount: raw.sectionCount, sections: [], check: raw.check,
        tracker: Tracker.sanitize(raw.tracker)
      };
      return { ok: true, record: rec, rawSections: Array.isArray(raw.sections) ? raw.sections : [] };
    } catch (e) {
      return { ok: false, reason: 'exception' };
    }
  }

  /** Rebuild section objects from a validated record, re-checking every section id and the joined text. */
  function restoreSections(valid, record) {
    const raw = valid.rawSections;
    const source = record.splitIsText ? record.text : record.splitSource;
    if (!raw.length || typeof source !== 'string') return { sections: [], splitSource: null };
    const sections = [];
    for (let i = 0; i < raw.length; i++) {
      const s = raw[i];
      if (!s || typeof s.text !== 'string' || !s.text.length || Splitter.sectionId(s.text) !== s.id) {
        return { sections: [], splitSource: source, damaged: true };
      }
      sections.push({ number: i + 1, text: s.text, id: s.id, chars: Splitter.countChars(s.text), words: Splitter.countWords(s.text) });
    }
    if (sections.map(s => s.text).join('') !== source) return { sections: [], splitSource: source, damaged: true };
    return { sections, splitSource: source };
  }

  /** Choose the newest valid candidate. Candidates: [{ok, record, source}] */
  function pickBest(candidates) {
    let best = null;
    for (const c of candidates) {
      if (!c || !c.ok) continue;
      if (!best || c.record.seq > best.record.seq ||
          (c.record.seq === best.record.seq && c.record.savedAt > best.record.savedAt)) best = c;
    }
    return best;
  }

  const slotFor = seq => (seq % 2 === 0 ? 'A' : 'B');

  return { VERSION, checksum, build, validate, restoreSections, pickBest, slotFor };
});
