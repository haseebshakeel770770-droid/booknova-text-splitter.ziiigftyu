/* BookNova Text Counter & Smart Splitter - UI controller */
(function () {
  'use strict';

  const Splitter = window.BookNovaSplitter;
  const Tracker = window.BookNovaTracker;
  const Store = window.BookNovaStorage;
  const Session = window.BookNovaSession;
  const Native = window.BookNovaNative;
  const $ = id => document.getElementById(id);

  const source = $('sourceText');
  const targetInput = $('targetSize');
  const smartBox = $('smartMode');
  const headerBox = $('headerMode');

  let sections = [];          // sections currently shown
  let splitSource = null;     // exact text the shown sections were made from
  let tracker = Tracker.emptyState();
  let cards = [];             // DOM cards, index-aligned with `sections`
  let reconciled = null;      // last reconcile() result
  let lastAllSignature = '';
  const buttonTimers = new WeakMap();
  let toastTimer = null;
  let manualContext = null;
  let backPressedAt = 0;

  /* ---------- helpers ---------- */
  const fmt = n => Number(n).toLocaleString();
  const timeText = ts => {
    try {
      return new Date(ts).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) { return String(ts); }
  };

  function toast(message, isError) {
    const el = $('toast');
    el.textContent = message;
    el.classList.toggle('error', !!isError);
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), isError ? 3200 : 1800);
  }

  function signatureOf(list) {
    return Splitter.sectionId(list.map(s => s.id).join('|'));
  }

  /* ---------- automatic saving ---------- */
  // Nothing is saved until the previous session has been read (ready = true), so an empty screen at
  // start-up can never overwrite saved work.
  let ready = false;
  let seq = 0;
  let saveTimer = null;
  let saveChain = Promise.resolve();
  let storageProblem = false;
  const statusEl = $('saveStatus');

  function setStatus(kind, text) {
    statusEl.className = 'save-status' + (kind ? ' ' + kind : '');
    statusEl.textContent = text;
  }
  const clockText = ts => { try { return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }); } catch (e) { return ''; } };

  function snapshot() {
    return {
      text: source.value, target: targetInput.value, smart: smartBox.checked, headers: headerBox.checked,
      splitSource: splitSource, sections: sections, tracker: tracker
    };
  }

  /** Save soon (debounced). Used while typing and for small setting changes. */
  function scheduleSave(delay) {
    if (!ready) return;
    setStatus('warn', 'Saving…');
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { saveNow(); }, delay === undefined ? 500 : delay);
  }

  /** Save immediately. Writes are queued one after another so they can never interleave. */
  function saveNow() {
    if (!ready) return Promise.resolve(null);
    clearTimeout(saveTimer);
    const snap = snapshot();
    saveChain = saveChain.then(async () => {
      try {
        seq += 1;
        const record = Session.build(snap, seq, Date.now());
        const res = await Store.saveSession(record);
        await Store.saveLight({ seq, savedAt: record.savedAt, settings: { target: record.target, smart: record.smart, headers: record.headers }, tracker: record.tracker });
        if (res.ok) {
          storageProblem = false;
          setStatus('ok', 'Saved ✓ ' + clockText(record.savedAt));
        } else {
          storageProblem = true;
          setStatus('bad', '⚠ Could not save on this device');
        }
        return res;
      } catch (e) {
        storageProblem = true;
        setStatus('bad', '⚠ Could not save on this device');
        return null;
      }
    });
    return saveChain;
  }

  /* ---------- counters ---------- */
  function updateStats() {
    const text = source.value;
    $('charCount').textContent = fmt(Splitter.countChars(text));
    $('noSpaceCount').textContent = fmt(Splitter.countNoSpace(text));
    $('wordCount').textContent = fmt(Splitter.countWords(text));
    $('paragraphCount').textContent = fmt(Splitter.countParagraphs(text));
  }

  function updateOutdated() {
    $('outdatedBanner').hidden = !(sections.length && splitSource !== null && source.value !== splitSource);
  }

  /* ---------- target validation ---------- */
  function showTargetError(msg) {
    const box = $('targetError');
    box.hidden = !msg;
    box.textContent = msg || '';
    targetInput.setAttribute('aria-invalid', msg ? 'true' : 'false');
  }
  function checkTarget() {
    const v = Splitter.validateTarget(targetInput.value);
    showTargetError(v.ok ? '' : v.error);
    document.querySelectorAll('.chip-btn').forEach(b => b.classList.toggle('on', v.ok && Number(b.dataset.target) === v.value));
    updateLimitNote(v.ok ? v.value : null);
    return v;
  }
  function updateLimitNote(target) {
    const note = $('limitNote');
    if (!target) {
      note.textContent = 'Choose a target between ' + fmt(Splitter.MIN_TARGET) + ' and ' + fmt(Splitter.MAX_TARGET) + ' characters.';
      return;
    }
    const max = target + Splitter.toleranceFor(target);
    note.textContent = smartBox.checked
      ? 'Smart splitting aims for ' + fmt(target) + ' characters and may run slightly over to finish a sentence, but never above ' + fmt(max) +
        '. If no punctuation is available it cuts at a space, and as a last resort at a safe character boundary, so no text is ever lost or changed.'
      : 'Strict mode cuts every section at no more than ' + fmt(target) + ' characters, without waiting for the end of a sentence. No text is lost or changed.';
  }

  /* ---------- rendering ---------- */
  function makeEmpty() {
    const d = document.createElement('div');
    d.className = 'empty';
    d.innerHTML = '<strong>No sections yet</strong><span>Paste your text above, set a target size and tap <strong>Split text</strong>.</span>';
    return d;
  }

  function render() {
    const container = $('chunks');
    container.textContent = '';
    cards = [];
    const has = sections.length > 0;
    $('copyAllBtn').disabled = $('downloadBtn').disabled = !has;
    if (!has) {
      container.appendChild(makeEmpty());
      $('resultSummary').textContent = 'Your sections will appear here.';
      applyMarkers();
      updateOutdated();
      return;
    }
    const total = sections.reduce((n, s) => n + s.chars, 0);
    $('resultSummary').textContent = sections.length + ' section' + (sections.length === 1 ? '' : 's') + ' · ' + fmt(total) + ' characters in total';

    const frag = document.createDocumentFragment();
    sections.forEach((sec, index) => {
      const card = document.createElement('article');
      card.className = 'chunk';
      card.id = 'section-' + sec.number;

      const head = document.createElement('div'); head.className = 'chunk-head';
      const info = document.createElement('div'); info.className = 'chunk-info';
      const title = document.createElement('div'); title.className = 'chunk-title';
      const name = document.createElement('span'); name.textContent = 'Section ' + sec.number;
      const badge = document.createElement('span'); badge.className = 'badge'; badge.hidden = true;
      title.append(name, badge);
      const meta = document.createElement('div'); meta.className = 'chunk-meta';
      meta.textContent = fmt(sec.chars) + ' characters · ' + fmt(sec.words) + ' words';
      info.append(title, meta);

      const btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'secondary chunk-copy'; btn.textContent = 'Copy section';
      btn.setAttribute('aria-label', 'Copy section ' + sec.number);
      btn.addEventListener('click', () => copySection(index, btn));

      head.append(info, btn);
      const body = document.createElement('div'); body.className = 'chunk-body'; body.textContent = sec.text;
      body.tabIndex = 0;
      body.setAttribute('aria-label', 'Text of section ' + sec.number);
      card.append(head, body);
      frag.appendChild(card);
      cards.push({ card, badge, btn });
    });
    container.appendChild(frag);
    applyMarkers();
    updateOutdated();
  }

  /** Re-check the tracker against what is on screen and update badges + summary bar. */
  function applyMarkers() {
    lastAllSignature = sections.length ? signatureOf(sections) : '';
    reconciled = Tracker.reconcile(tracker, sections, lastAllSignature);
    if (reconciled.changed) { tracker = reconciled.state; scheduleSave(300); }

    const activeIndex = reconciled.section.status === 'active' ? reconciled.section.index : -1;
    const dim = tracker.lastOperation === 'all';
    cards.forEach((c, i) => {
      const on = i === activeIndex;
      c.card.classList.toggle('is-last', on);
      c.card.classList.toggle('dim', on && dim);
      c.badge.hidden = !on;
      c.badge.classList.toggle('dim', on && dim);
      c.badge.textContent = on ? (dim ? 'LAST SECTION COPIED ✓' : 'LAST COPIED ✓') : '';
    });
    renderLastBar();
  }

  function renderLastBar() {
    const bar = $('lastBar');
    const hasAny = tracker.lastSection || tracker.lastAll;
    bar.hidden = !hasAny;
    if (!hasAny) return;

    const sec = reconciled ? reconciled.section : { status: 'none' };
    const all = reconciled ? reconciled.all : { status: 'none' };
    const title = $('lastTitle');
    const detail = $('lastDetail');
    const jump = $('jumpBtn');
    const lines = [];
    let stale = false;

    if (tracker.lastOperation === 'all' && tracker.lastAll) {
      title.textContent = 'Last copied: ALL sections (Copy all) ✓';
      lines.push(timeText(tracker.lastAll.copiedAt) + ' · ' + tracker.lastAll.sectionCount + ' sections · ' + fmt(tracker.lastAll.chars) + ' characters');
      if (all.status === 'stale') { lines.push('The sections have changed since this copy, so it may no longer match what is on screen.'); stale = true; }
      if (tracker.lastSection) {
        lines.push(sec.status === 'active'
          ? 'Last single section copied: Section ' + tracker.lastSection.number + ' at ' + timeText(tracker.lastSection.copiedAt) + '.'
          : 'Last single section copied (Section ' + tracker.lastSection.number + ') is no longer in the current text.');
      }
    } else if (tracker.lastSection) {
      if (sec.status === 'active') {
        title.textContent = 'Last copied: Section ' + tracker.lastSection.number + ' ✓';
        lines.push(timeText(tracker.lastSection.copiedAt) + ' · ' + fmt(tracker.lastSection.chars) + ' characters');
      } else {
        title.textContent = 'Last copied section is not in the current text';
        lines.push('Section ' + tracker.lastSection.number + ' was copied at ' + timeText(tracker.lastSection.copiedAt) +
          ', but the text has changed, so no section is marked.');
        stale = true;
      }
      if (tracker.lastAll) {
        lines.push(all.status === 'active' ? 'Copy all was also used at ' + timeText(tracker.lastAll.copiedAt) + '.' : '');
      }
    }
    detail.textContent = lines.filter(Boolean).join(' ');
    bar.classList.toggle('stale', stale);
    jump.hidden = !(sec.status === 'active');

    // Copy-all indicator on the toolbar button (separate from any section marker)
    const allBtn = $('copyAllBtn');
    if (!buttonTimers.has(allBtn)) {
      allBtn.textContent = tracker.lastOperation === 'all' && all.status === 'active' ? 'Copy all sections · LAST COPIED ✓' : 'Copy all sections';
    }

    const list = $('historyList');
    list.textContent = '';
    tracker.history.slice(0, 10).forEach(h => {
      const li = document.createElement('li');
      const strong = document.createElement('strong');
      strong.textContent = h.type === 'all' ? 'All sections' : 'Section ' + h.number;
      li.append(strong, document.createTextNode(' · ' + timeText(h.copiedAt)));
      list.appendChild(li);
    });
  }

  /* ---------- copy actions ---------- */
  function flashButton(btn, doneText, restoreText) {
    clearTimeout(buttonTimers.get(btn));
    btn.textContent = doneText;
    btn.classList.add('done');
    const t = setTimeout(() => {
      buttonTimers.delete(btn);
      btn.classList.remove('done');
      btn.textContent = typeof restoreText === 'function' ? restoreText() : restoreText;
    }, 1500);
    buttonTimers.set(btn, t);
  }

  function openManual(text, onConfirmed) {
    manualContext = { onConfirmed };
    $('manualText').value = text;
    $('manualModal').hidden = false;
    setTimeout(() => { const t = $('manualText'); t.focus(); t.select(); }, 50);
  }
  function closeManual() {
    $('manualModal').hidden = true;
    manualContext = null;
    $('manualText').value = '';
  }

  function commitSectionCopy(sec) {
    tracker = Tracker.recordSectionCopy(tracker, sec, Date.now());
    applyMarkers();
    saveNow();
  }

  async function copySection(index, btn) {
    const sec = sections[index];
    if (!sec) return;
    const ok = await Native.copyText(sec.text);
    if (ok) {
      commitSectionCopy(sec);
      flashButton(btn, 'COPIED ✓', 'Copy section');
      toast('Section ' + sec.number + ' copied');
    } else {
      toast('Could not copy automatically. Use the manual copy box.', true);
      openManual(sec.text, () => { commitSectionCopy(sec); flashButton(btn, 'COPIED ✓', 'Copy section'); });
    }
  }

  function commitCopyAll() {
    tracker = Tracker.recordCopyAll(tracker, {
      signature: signatureOf(sections), sectionCount: sections.length,
      chars: sections.reduce((n, s) => n + s.chars, 0)
    }, Date.now());
    applyMarkers();
    saveNow();
  }

  async function copyAll() {
    if (!sections.length) return;
    const btn = $('copyAllBtn');
    const text = Splitter.joinSections(sections, headerBox.checked);
    const ok = await Native.copyText(text);
    const restore = () => (tracker.lastOperation === 'all' && reconciled && reconciled.all.status === 'active')
      ? 'Copy all sections · LAST COPIED ✓' : 'Copy all sections';
    if (ok) {
      commitCopyAll();
      flashButton(btn, 'COPIED ✓', restore);
      toast('All ' + sections.length + ' sections copied');
    } else {
      toast('Could not copy automatically. Use the manual copy box.', true);
      openManual(text, () => { commitCopyAll(); flashButton(btn, 'COPIED ✓', restore); });
    }
  }

  async function downloadAll() {
    if (!sections.length) return;
    const d = new Date();
    const p = n => String(n).padStart(2, '0');
    const name = 'booknova-sections-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + '.txt';
    try {
      const result = await Native.saveTextFile(name, Splitter.joinSections(sections, headerBox.checked));
      if (result === 'saved') toast('Saved ' + name);
      else if (result === 'shared') toast('Choose where to save the .txt file');
    } catch (e) {
      toast('Could not create the .txt file.', true);
    }
  }

  /* ---------- split / clear ---------- */
  function doSplit(silent) {
    const text = source.value;
    const v = checkTarget();
    if (!v.ok) { if (!silent) { toast(v.error, true); targetInput.focus(); } return false; }
    if (!text.trim()) {
      if (!silent) toast('Please paste some text first', true);
      return false;
    }
    const res = Splitter.splitText(text, v.value, { smart: smartBox.checked });
    if (!res.ok) { toast(res.error, true); return false; }
    sections = res.sections;
    splitSource = text;
    render();
    if (!silent) saveNow();
    if (!silent) {
      toast(sections.length + ' section' + (sections.length === 1 ? '' : 's') + ' created');
      const top = $('resultsSection');
      if (top && top.scrollIntoView) top.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    return true;
  }

  /* Clear all: asks first. Nothing is deleted unless the user confirms. */
  function askClearAll() {
    $('clearModal').hidden = false;
    setTimeout(() => $('clearCancel').focus(), 30);
  }
  function closeClearDialog() { $('clearModal').hidden = true; }

  async function confirmClearAll() {
    closeClearDialog();
    clearTimeout(saveTimer);
    await saveChain; // let any write in flight finish first
    source.value = '';
    sections = []; splitSource = null; cards = [];
    tracker = Tracker.emptyState();
    updateStats();
    render();
    await Store.deleteEverything();
    // A new empty record with a higher sequence number guarantees that no leftover copy can come back.
    await saveNow();
    setStatus('ok', 'Saved data deleted');
    source.focus();
    toast('Everything was deleted');
  }

  /* ---------- back button ---------- */
  function handleBack() {
    if (!$('clearModal').hidden) { closeClearDialog(); return true; }
    if (!$('manualModal').hidden) { closeManual(); return true; }
    const box = $('historyBox');
    if (box && box.open) { box.open = false; return true; }
    if (document.activeElement === source) { source.blur(); return true; }
    if (window.scrollY > 120) { window.scrollTo({ top: 0, behavior: 'smooth' }); return true; }
    const now = Date.now();
    if (now - backPressedAt < 2000) { saveNow(); return false; }
    backPressedAt = now;
    toast('Press back again to exit');
    return true;
  }

  /* ---------- wiring ---------- */
  function bind() {
    source.addEventListener('input', () => { updateStats(); updateOutdated(); scheduleSave(500); });
    targetInput.addEventListener('input', () => { checkTarget(); scheduleSave(300); });
    smartBox.addEventListener('change', () => { checkTarget(); scheduleSave(300); });
    headerBox.addEventListener('change', () => scheduleSave(300));
    document.querySelectorAll('.chip-btn').forEach(b => b.addEventListener('click', () => {
      targetInput.value = b.dataset.target; checkTarget(); scheduleSave(300);
    }));
    $('splitBtn').addEventListener('click', () => doSplit(false));
    $('clearBtn').addEventListener('click', askClearAll);
    $('clearCancel').addEventListener('click', closeClearDialog);
    $('clearConfirm').addEventListener('click', confirmClearAll);
    $('copyAllBtn').addEventListener('click', copyAll);
    $('downloadBtn').addEventListener('click', downloadAll);
    $('pasteBtn').addEventListener('click', async () => {
      const text = await Native.readClipboard();
      if (typeof text === 'string' && text.length) {
        const start = source.selectionStart, end = source.selectionEnd;
        if (document.activeElement === source && typeof start === 'number') {
          source.setRangeText(text, start, end, 'end');
        } else {
          source.value = source.value ? source.value + text : text;
        }
        updateStats(); updateOutdated(); scheduleSave(500);
        toast('Pasted');
      } else {
        toast('Nothing to paste. You can also long-press the text box and choose Paste.', true);
        source.focus();
      }
    });
    $('jumpBtn').addEventListener('click', () => {
      if (reconciled && reconciled.section.status === 'active') {
        const c = cards[reconciled.section.index];
        if (c) c.card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
    $('clearHistoryBtn').addEventListener('click', () => {
      tracker = Object.assign({}, tracker, { history: [] });
      saveNow(); renderLastBar();
    });
    $('manualDone').addEventListener('click', () => {
      const ctx = manualContext; closeManual();
      if (ctx && ctx.onConfirmed) { ctx.onConfirmed(); toast('Marked as copied'); }
    });
    $('manualCancel').addEventListener('click', closeManual);
    // Flush immediately whenever the app may be about to go away.
    const flush = () => { saveNow(); };
    document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
    window.addEventListener('pagehide', flush);
    window.addEventListener('blur', flush);
    source.addEventListener('blur', flush);
    Native.setupLifecycle(handleBack, flush);
  }

  /* ---------- start / restore ---------- */
  function applySettings(st) {
    if (!st || typeof st !== 'object') return;
    if (st.target !== undefined && st.target !== null) targetInput.value = st.target;
    if (typeof st.smart === 'boolean') smartBox.checked = st.smart;
    if (typeof st.headers === 'boolean') headerBox.checked = st.headers;
  }

  function enableInput() {
    source.disabled = false;
    $('pasteBtn').disabled = false;
    $('splitBtn').disabled = false;
    $('clearBtn').disabled = false;
  }

  async function init() {
    bind();
    updateStats();
    checkTarget();
    render();
    Store.requestPersistence();
    let restoredMsg = null;

    try {
      const loaded = await Store.loadSession();
      seq = loaded.maxSeq || 0;

      if (loaded.status === 'restored') {
        const rec = loaded.record;
        source.value = rec.text;
        applySettings({ target: rec.target, smart: rec.smart, headers: rec.headers });
        tracker = Tracker.sanitize(rec.tracker);
        const rs = Session.restoreSections(loaded.valid, rec);
        if (rs.sections.length) {
          sections = rs.sections; splitSource = rs.splitSource;
        } else if (rs.splitSource) {
          // Saved sections were damaged: rebuild them from the saved text with the saved settings.
          const again = Splitter.splitText(rs.splitSource, rec.target, { smart: rec.smart });
          if (again.ok && again.sections.length) { sections = again.sections; splitSource = rs.splitSource; }
        }
        if (rec.text.length) {
          restoredMsg = sections.length ? 'Previous session restored · ' + sections.length + ' section' + (sections.length === 1 ? '' : 's')
            : 'Previous text restored';
        }
        setStatus('ok', 'Restored ✓ saved ' + clockText(rec.savedAt));
      } else if (loaded.status === 'empty') {
        // First run of this version: bring over anything saved by version 1 of the app.
        const old = await Store.loadLegacy();
        if (old) {
          source.value = old.text;
          if (old.settings) applySettings(old.settings);
          tracker = Tracker.sanitize(old.tracker);
          if (old.split) {
            const res = Splitter.splitText(old.text, targetInput.value, { smart: smartBox.checked });
            if (res.ok && res.sections.length) { sections = res.sections; splitSource = old.text; }
          }
          restoredMsg = 'Previous work restored';
        } else {
          const light = await Store.loadLight();
          if (light) { applySettings(light.settings); tracker = Tracker.sanitize(light.tracker); }
          setStatus('', 'Auto-save is on');
        }
      } else {
        // 'damaged' or 'error': do not pretend there is nothing; tell the user plainly.
        const light = await Store.loadLight();
        if (light) { applySettings(light.settings); tracker = Tracker.sanitize(light.tracker); }
        storageProblem = true;
        setStatus('bad', loaded.status === 'error' ? '⚠ Saved data could not be read' : '⚠ Saved data was damaged');
        toast(loaded.status === 'error' ? 'Your saved data could not be read. New work will still be saved.' : 'Your saved data was damaged and could not be restored.', true);
      }
    } catch (e) {
      storageProblem = true;
      setStatus('bad', '⚠ Saved data could not be read');
    }

    updateStats();
    checkTarget();
    render();               // draws sections (if any) and applies the Last Copied marker
    enableInput();
    ready = true;           // only now may anything be saved
    document.documentElement.setAttribute('data-ready', '1');
    if (restoredMsg) toast(restoredMsg);
  }

  init();
})();
