/*
 * Native bridge helpers: clipboard, file saving/sharing and back button.
 * Each function has a browser fallback so the same www/ folder also works in Chrome for quick testing.
 */
(function () {
  'use strict';

  const cap = () => window.Capacitor;
  const isNative = () => !!(cap() && cap().isNativePlatform && cap().isNativePlatform());
  const plugin = name => (cap() && cap().Plugins && cap().Plugins[name]) || null;

  /** Copy text. Resolves true only if a copy method really succeeded. */
  async function copyText(text) {
    const clip = plugin('Clipboard');
    if (isNative() && clip) {
      try { await clip.write({ string: text }); return true; } catch (e) { /* try web methods */ }
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext !== false) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (e) { /* try execCommand */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
      document.body.appendChild(ta);
      ta.focus({ preventScroll: true });
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      ta.remove();
      return ok === true;
    } catch (e) { return false; }
  }

  /** Read the clipboard (for the Paste button). Returns a string or null. */
  async function readClipboard() {
    const clip = plugin('Clipboard');
    if (isNative() && clip) {
      try {
        const r = await clip.read();
        if (r && typeof r.value === 'string') return r.value;
      } catch (e) { /* fall through */ }
    }
    try { if (navigator.clipboard && navigator.clipboard.readText) return await navigator.clipboard.readText(); } catch (e) { /* none */ }
    return null;
  }

  /**
   * Save text as a .txt file. On Android the file is written to the app cache and the system share sheet
   * opens, so the user can pick Files / Drive / WhatsApp etc. (no storage permission needed).
   * Returns 'saved' | 'shared' | 'cancelled'; throws on real failure.
   */
  async function saveTextFile(filename, content) {
    const fs = plugin('Filesystem');
    const share = plugin('Share');
    if (isNative() && fs && share) {
      const written = await fs.writeFile({ path: filename, data: content, directory: 'CACHE', encoding: 'utf8' });
      try {
        await share.share({ title: filename, dialogTitle: 'Save or share your sections', url: written.uri });
        return 'shared';
      } catch (e) {
        if (/cancel/i.test(String((e && e.message) || e))) return 'cancelled';
        throw e;
      }
    }
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return 'saved';
  }

  /** Register handlers. onBack() must return true if it handled the press. */
  function setupLifecycle(onBack, onPause) {
    const app = plugin('App');
    if (!isNative() || !app) return;
    try {
      app.addListener('backButton', () => {
        if (onBack && onBack()) return;
        try { app.exitApp(); } catch (e) { /* ignore */ }
      });
      app.addListener('pause', () => { if (onPause) onPause(); });
      app.addListener('appStateChange', st => { if (st && st.isActive === false && onPause) onPause(); });
    } catch (e) { /* ignore */ }
  }

  window.BookNovaNative = { isNative, copyText, readClipboard, saveTextFile, setupLifecycle };
})();
