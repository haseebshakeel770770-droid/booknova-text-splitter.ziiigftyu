/*
 * Last-copied tracking. Pure functions over a plain JSON state object so it can be persisted
 * and unit-tested. Section markers are keyed by content id, never by position alone.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BookNovaTracker = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const HISTORY_LIMIT = 20;

  function emptyState() {
    return { version: 1, lastOperation: null, lastSection: null, lastAll: null, history: [] };
  }

  const isNum = v => typeof v === 'number' && Number.isFinite(v);

  /** Accepts anything read from storage and returns a safe state object. */
  function sanitize(raw) {
    const s = emptyState();
    if (!raw || typeof raw !== 'object') return s;
    const ls = raw.lastSection;
    if (ls && isNum(ls.number) && typeof ls.id === 'string' && isNum(ls.copiedAt)) {
      s.lastSection = { number: ls.number, id: ls.id, copiedAt: ls.copiedAt, chars: isNum(ls.chars) ? ls.chars : 0 };
    }
    const la = raw.lastAll;
    if (la && typeof la.signature === 'string' && isNum(la.copiedAt)) {
      s.lastAll = {
        signature: la.signature, copiedAt: la.copiedAt,
        sectionCount: isNum(la.sectionCount) ? la.sectionCount : 0, chars: isNum(la.chars) ? la.chars : 0
      };
    }
    if (Array.isArray(raw.history)) {
      s.history = raw.history.filter(h => h && (h.type === 'section' || h.type === 'all') && isNum(h.copiedAt))
        .slice(0, HISTORY_LIMIT)
        .map(h => ({
          type: h.type, number: isNum(h.number) ? h.number : null, id: typeof h.id === 'string' ? h.id : '',
          sectionCount: isNum(h.sectionCount) ? h.sectionCount : null, copiedAt: h.copiedAt
        }));
    }
    s.lastOperation = (raw.lastOperation === 'section' && s.lastSection) ? 'section'
      : (raw.lastOperation === 'all' && s.lastAll) ? 'all'
      : (s.lastSection ? 'section' : s.lastAll ? 'all' : null);
    return s;
  }

  function pushHistory(state, entry) {
    return [entry].concat(state.history).slice(0, HISTORY_LIMIT);
  }

  function recordSectionCopy(state, section, now) {
    const next = sanitize(state);
    next.lastSection = { number: section.number, id: section.id, chars: section.chars, copiedAt: now };
    next.lastOperation = 'section';
    next.history = pushHistory(next, { type: 'section', number: section.number, id: section.id, sectionCount: null, copiedAt: now });
    return next;
  }

  function recordCopyAll(state, info, now) {
    const next = sanitize(state);
    next.lastAll = { signature: info.signature, sectionCount: info.sectionCount, chars: info.chars, copiedAt: now };
    next.lastOperation = 'all';
    next.history = pushHistory(next, { type: 'all', number: null, id: '', sectionCount: info.sectionCount, copiedAt: now });
    return next;
  }

  /**
   * Compare the stored state with the sections currently on screen.
   * Returns { state, changed, section: {status, index}, all: {status} }
   * status: 'active' = still matches the current content, 'stale' = content no longer present, 'none'.
   * A section marker moves only if the exact same content now sits at another position.
   * It is never pointed at different content.
   */
  function reconcile(state, sections, allSignature) {
    const next = sanitize(state);
    let changed = false;
    const result = { section: { status: 'none', index: -1 }, all: { status: 'none' } };

    if (next.lastSection) {
      const wanted = next.lastSection;
      const hits = [];
      sections.forEach((s, i) => { if (s.id === wanted.id) hits.push(i); });
      if (!hits.length) {
        result.section = { status: 'stale', index: -1 };
      } else {
        let best = hits[0];
        for (const h of hits) {
          if (Math.abs(h + 1 - wanted.number) < Math.abs(best + 1 - wanted.number)) best = h;
        }
        if (best + 1 !== wanted.number) {
          next.lastSection = Object.assign({}, wanted, { number: best + 1 });
          changed = true;
        }
        result.section = { status: 'active', index: best };
      }
    }
    if (next.lastAll) {
      result.all = { status: allSignature && next.lastAll.signature === allSignature ? 'active' : 'stale' };
    }
    return { state: next, changed, section: result.section, all: result.all };
  }

  return { HISTORY_LIMIT, emptyState, sanitize, recordSectionCopy, recordCopyAll, reconcile };
});
