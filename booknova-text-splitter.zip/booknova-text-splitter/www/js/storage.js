/*
 * Permanent local storage. Nothing here ever leaves the device.
 *
 *  1. IndexedDB (WebView app data)  - main copy of the session (large text + sections)
 *  2. App-private file (Capacitor Filesystem, Directory.Data) - independent second copy (native only)
 *  3. Capacitor Preferences (SharedPreferences) / localStorage - small settings + tracker
 *
 * The session is written to two alternating slots (A/B) in both IndexedDB and the file store. A new save
 * never overwrites the previous good copy, so a crash in the middle of a write cannot lose your work.
 * On start the newest slot that passes its checksum wins.
 */
(function () {
  'use strict';

  const Session = window.BookNovaSession;
  const DB_NAME = 'booknova-db';
  const STORE = 'kv';
  const SLOTS = ['A', 'B'];
  const LIGHT_KEY = 'light';
  const PREFIX = 'booknova.';

  const cap = () => window.Capacitor;
  const isNative = () => !!(cap() && cap().isNativePlatform && cap().isNativePlatform());
  const plugin = n => (cap() && cap().Plugins && cap().Plugins[n]) || null;
  const nativePrefs = () => (isNative() ? plugin('Preferences') : null);
  const nativeFs = () => (isNative() ? plugin('Filesystem') : null);

  /* ---------- IndexedDB ---------- */
  let dbPromise = null;
  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('IndexedDB unavailable')); return; }
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => { db.close(); dbPromise = null; };
        resolve(db);
      };
      req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
      req.onblocked = () => reject(new Error('IndexedDB blocked'));
    });
    dbPromise.catch(() => { dbPromise = null; });
    return dbPromise;
  }
  async function idbGet(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const r = tx.objectStore(STORE).get(key);
      r.onsuccess = () => resolve(r.result === undefined ? null : r.result);
      r.onerror = () => reject(r.error);
      tx.onabort = () => reject(tx.error || new Error('IndexedDB read aborted'));
    });
  }
  async function idbSet(key, value) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(value, key);
      tx.oncomplete = () => resolve(true); // resolves only after the data is committed
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted'));
    });
  }
  async function idbDelete(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('IndexedDB delete aborted'));
    });
  }

  /* ---------- File store (native only) ---------- */
  const fileName = slot => 'booknova-session-' + slot + '.json';
  async function fileGet(slot) {
    const fs = nativeFs();
    if (!fs) return { available: false, value: null };
    try {
      const r = await fs.readFile({ path: fileName(slot), directory: 'DATA', encoding: 'utf8' });
      return { available: true, value: r && typeof r.data === 'string' ? r.data : null };
    } catch (e) {
      // "File does not exist" is normal on first run and is not an error.
      if (/not exist|no such|not found|ENOENT/i.test(String((e && e.message) || e))) return { available: true, value: null };
      throw e;
    }
  }
  async function fileSet(slot, text) {
    const fs = nativeFs();
    if (!fs) return false;
    await fs.writeFile({ path: fileName(slot), data: text, directory: 'DATA', encoding: 'utf8', recursive: true });
    return true;
  }
  async function fileDelete(slot) {
    const fs = nativeFs();
    if (!fs) return;
    try { await fs.deleteFile({ path: fileName(slot), directory: 'DATA' }); } catch (e) { /* already gone */ }
  }

  /* ---------- Small values: Preferences + localStorage mirror ---------- */
  async function lightGet(key) {
    const prefs = nativePrefs();
    if (prefs) {
      try {
        const r = await prefs.get({ key: PREFIX + key });
        if (r && r.value !== null && r.value !== undefined) return r.value;
      } catch (e) { /* fall back */ }
    }
    try { return window.localStorage.getItem(PREFIX + key); } catch (e) { return null; }
  }
  async function lightSet(key, value) {
    let saved = false;
    const prefs = nativePrefs();
    if (prefs) { try { await prefs.set({ key: PREFIX + key, value: String(value) }); saved = true; } catch (e) { /* try next */ } }
    try { window.localStorage.setItem(PREFIX + key, String(value)); saved = true; } catch (e) { /* ignore */ }
    return saved;
  }
  async function lightRemove(key) {
    const prefs = nativePrefs();
    if (prefs) { try { await prefs.remove({ key: PREFIX + key }); } catch (e) { /* ignore */ } }
    try { window.localStorage.removeItem(PREFIX + key); } catch (e) { /* ignore */ }
  }
  async function lightGetJSON(key, fallback) {
    const raw = await lightGet(key);
    if (raw === null || raw === undefined) return fallback;
    try { return JSON.parse(raw); } catch (e) { return fallback; }
  }

  /* ---------- Session API ---------- */

  /**
   * Read every copy and pick the newest valid one.
   * Returns { status: 'restored'|'empty'|'error', record?, valid?, maxSeq, sources, problems }
   *   'empty' = nothing was stored (first run).  'error' = storage could not be read at all.
   */
  async function loadSession() {
    const candidates = [];
    const problems = [];
    let readsAttempted = 0, readsFailed = 0, foundAny = false;

    for (const slot of SLOTS) {
      readsAttempted++;
      try {
        const raw = await idbGet('slot' + slot);
        if (raw !== null) {
          foundAny = true;
          const v = Session.validate(raw);
          if (v.ok) candidates.push({ ok: true, record: v.record, valid: v, source: 'database' });
          else problems.push('database slot ' + slot + ': ' + v.reason);
        }
      } catch (e) { readsFailed++; problems.push('database slot ' + slot + ' unreadable'); }

      if (nativeFs()) {
        readsAttempted++;
        try {
          const f = await fileGet(slot);
          if (f.value !== null) {
            foundAny = true;
            let parsed = null;
            try { parsed = JSON.parse(f.value); } catch (e) { problems.push('file slot ' + slot + ': not valid JSON'); }
            if (parsed) {
              const v = Session.validate(parsed);
              if (v.ok) candidates.push({ ok: true, record: v.record, valid: v, source: 'file' });
              else problems.push('file slot ' + slot + ': ' + v.reason);
            }
          }
        } catch (e) { readsFailed++; problems.push('file slot ' + slot + ' unreadable'); }
      }
    }

    const best = Session.pickBest(candidates);
    const maxSeq = candidates.reduce((m, c) => Math.max(m, c.record.seq), 0);
    if (best) {
      return { status: 'restored', record: best.record, valid: best.valid, source: best.source, maxSeq, sources: candidates.length, problems };
    }
    if (readsFailed > 0 && readsFailed === readsAttempted) return { status: 'error', maxSeq: 0, problems };
    return { status: foundAny ? 'damaged' : 'empty', maxSeq: 0, problems };
  }

  /**
   * Write one record to the next slot in the database and (on Android) the private file.
   * Resolves { ok, database, file }. ok is true if at least one copy was committed.
   */
  async function saveSession(record) {
    const slot = Session.slotFor(record.seq);
    const result = { ok: false, database: false, file: false };
    try { result.database = await idbSet('slot' + slot, record); } catch (e) { result.database = false; }
    if (nativeFs()) {
      try { result.file = await fileSet(slot, JSON.stringify(record)); } catch (e) { result.file = false; }
    }
    result.ok = result.database || result.file;
    return result;
  }

  /** Small, always-fresh copy of settings + tracker (used if the large record cannot be read). */
  const saveLight = obj => lightSet(LIGHT_KEY, JSON.stringify(obj));
  const loadLight = () => lightGetJSON(LIGHT_KEY, null);

  /** Data written by version 1 of the app (separate keys). Used once for migration. */
  async function loadLegacy() {
    const text = await lightGet('text');
    if (typeof text !== 'string' || !text.length) return null;
    return {
      text,
      settings: await lightGetJSON('settings', null),
      tracker: await lightGetJSON('tracker', null),
      split: (await lightGet('split')) === '1'
    };
  }

  /** Delete every stored copy. Called only after the user confirms "Clear all". */
  async function deleteEverything() {
    let ok = true;
    for (const slot of SLOTS) {
      try { await idbDelete('slot' + slot); } catch (e) { ok = false; }
      await fileDelete(slot);
    }
    for (const k of [LIGHT_KEY, 'text', 'settings', 'tracker', 'split']) await lightRemove(k);
    return ok;
  }

  /** Ask the browser engine not to evict our data under storage pressure (best effort). */
  async function requestPersistence() {
    try { if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch (e) { /* ignore */ }
    return false;
  }

  window.BookNovaStorage = { loadSession, saveSession, saveLight, loadLight, loadLegacy, deleteEverything, requestPersistence, isNative };
})();
